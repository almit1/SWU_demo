# Blazor App

Minimal Blazor WebAssembly app.

## Run
```bash
dotnet run
```
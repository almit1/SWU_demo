# Console Tool

Simple console tool.

## Run
```bash
dotnet run
```
# Inventory App

A simple console app that prints a message.

## Run
```bash
dotnet run
```
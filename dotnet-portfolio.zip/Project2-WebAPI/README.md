# Web API

A minimal Web API with one endpoint.

## Run
```bash
dotnet run
```